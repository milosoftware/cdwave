// se3.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "se3.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSe3App

BEGIN_MESSAGE_MAP(CSe3App, CWinApp)
	//{{AFX_MSG_MAP(CSe3App)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSe3App construction

CSe3App::CSe3App()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSe3App object

CSe3App theApp;
