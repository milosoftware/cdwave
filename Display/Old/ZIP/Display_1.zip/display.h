
#define  SUCCESS    0
#define  FAIL       -1


extern "C" long WINAPI  START( long numsamples, long *preferredchunksize, void **ref );
extern "C" long WINAPI  INITPARAMS( void **parameters, long *paramsize );
extern "C" long WINAPI  ANALYZE( void *ref, long numsamples, short *data );
extern "C" long WINAPI  DISPLAY( void *ref, CWnd *pPic, long startsample, long endsample,
                                 RECT dspRegion, RECT updRegion );
extern "C" long WINAPI   USERUI( void *ref, char *parameters, HWND parent );
extern "C" long WINAPI  END( void *ref );

